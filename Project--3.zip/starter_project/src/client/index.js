// js files
import { handleSubmit } from "./js/formHandler";
import { checkForName } from "./js/nameChecker";

//import './styles/resets.scss'
//import './styles/base.scss'
//import './styles/footer.scss'
//import './styles/form.scss'
//import './styles/header.scss'

alert("I EXIST");

// style sheets
require("./styles/resets.scss");
require("./styles/base.scss");
require("./styles/footer.scss");
require("./styles/form.scss");
require("./styles/header.scss");



console.log("CHANGE!!");

// sass files



const abc =() => {
  console.log("abc");

}

function xyz(){
  console.log("xyz");
}