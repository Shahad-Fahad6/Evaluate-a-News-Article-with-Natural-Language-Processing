// Replace checkForName with a function that checks the URL
import { checkForName } from './nameChecker';

// If working on Udacity workspace, update this with the Server API URL e.g. `https://wfkdhyvtzx.prod.udacity-student-workspaces.com/api`
// const serverURL = 'https://wfkdhyvtzx.prod.udacity-student-workspaces.com/api'
const serverURL = 'https://localhost:8000/api';

const form = document.getElementById('urlForm');
form.addEventListener('submit', handleSubmit);

function handleSubmit(event) {
    event.preventDefault();

    // Get the URL from the input field
    const formText = document.getElementById('name').value;

    if (isValidURL(formText)) {
        console.log("::: Form Submitted :::", formText);
        
        // Send the valid URL to the server
        sendToServer(formText);
    } else {
        console.error("Invalid URL submitted:", formText);
        alert("Please enter a valid URL.");
    }

    // This is an example code that checks the submitted name. You may remove it from your code
    checkForName(formText);
    
    // Check if the URL is valid
    console.log("::: Form Submitted :::");
        // If the URL is valid, send it to the server using the serverURL constant above
      
}

// Function to send data to the server
// Function to check if the URL is valid
function isValidURL(string) {
    const urlPattern = new RegExp('^(https?:\\/\\/)?' + // protocol
        '((([a-z\\d]([a-z\\d-]*[a-z\\d])?)\\.)+[a-z]{2,}|' + // domain name
        'localhost|' + // localhost
        '\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}|' + // IP address
        '\\[?[a-fA-F0-9]*:[a-fA-F0-9:]+\\]?)' + // IPv6
        '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' + // port and path
        '(\\?[;&a-z\\d%_.~+=-]*)?' + // query string
        '(\\#[-a-z\\d_]*)?$','i'); // fragment locator
    return !!urlPattern.test(string);
}

// Function to send data to the server
async function sendToServer(url) {
    try {
        const response = await fetch(serverURL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ url: url }),
        });

        if (!response.ok) {
            throw new Error('Network response was not ok ' + response.statusText);
        }

        const data = await response.json();
        console.log("Data received from server:", data);
    } catch (error) {
        console.error("Error sending data to server:", error);
    }
}
// Export the handleSubmit function
export { handleSubmit };

